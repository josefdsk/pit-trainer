scrns.tac is the tactical engagement which was created and used
to capture all the screenshots used to make the Pit Trainer app.
It is stored here in case the screens need to be re-created and
ensures the same environment, time of day, etc. will be selected.
