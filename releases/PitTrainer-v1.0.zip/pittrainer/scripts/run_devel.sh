#!/usr/bin/sh
java -Xms200M -Xmx300M -cp ../bin/PitTrainer.jar com.gpl.pittrainer.PitTrainer -devmode

